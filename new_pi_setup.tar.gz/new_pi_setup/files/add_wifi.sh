#!/bin/bash
# Save a WPA2 (password) WiFi network on the Pi and connect to it.
#   sudo bash ~/add_wifi.sh "BPRL_MOCAP"
#
# Writes a NetworkManager keyfile directly: on this Pi, saving a WiFi password
# with `nmcli device wifi connect` fails with "netplan generate failed".
# Removes any older profiles with the same name first. The network is
# remembered and reconnects automatically after reboots.
set -euo pipefail
[ "$(id -u)" -eq 0 ] || { echo "run with sudo" >&2; exit 1; }
ssid=${1:?usage: sudo bash add_wifi.sh "SSID"}

read -rsp "Password for $ssid: " psk; echo
if [ ${#psk} -lt 8 ] || [ ${#psk} -gt 63 ]; then
    echo "WPA2 passwords are 8-63 characters (got ${#psk})" >&2; exit 1
fi

# Old profiles with this name (including half-saved ones from failed attempts)
nmcli -t -f UUID,NAME connection show | while IFS=: read -r uuid name; do
    [ "$name" = "$ssid" ] || continue
    nmcli connection delete "$uuid" >/dev/null && echo "removed old profile $uuid"
done

file=/etc/NetworkManager/system-connections/${ssid//[^A-Za-z0-9_-]/_}.nmconnection
umask 077
cat > "$file" <<EOF
[connection]
id=$ssid
uuid=$(cat /proc/sys/kernel/random/uuid)
type=wifi
autoconnect=true

[wifi]
mode=infrastructure
ssid=$ssid

[wifi-security]
key-mgmt=wpa-psk
psk=$psk

[ipv4]
method=auto

[ipv6]
method=auto
EOF
chmod 600 "$file"
nmcli connection reload
echo "saved $file"

if nmcli connection up "$ssid"; then
    sleep 3
    ip -4 -br addr show wlan0
else
    echo "Saved, but could not connect now (out of range or wrong password?)." >&2
    echo "It will connect automatically when the network is in range." >&2
fi
