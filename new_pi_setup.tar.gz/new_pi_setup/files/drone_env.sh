# drone_position_hold shell setup (copied from the strain-drone Pi's .bashrc,
# old functions removed). Load it by adding this line to ~/.bashrc:
#   source ~/drone_env.sh

[ -f /opt/ros/jazzy/setup.bash ] && source /opt/ros/jazzy/setup.bash

export PATH="$PATH:$HOME/.local/bin"
alias mavproxy="source ~/mavlink_env/bin/activate && mavproxy.py"

source_ros() {
    cd ~/Documents/drone_position_hold/ros2_ws
    source install/setup.bash
    echo "ROS2 workspace setup complete!"
}

source_ros_vicon() {
    cd ~/Documents/drone_position_hold_Vicon/ros2_ws
    source install/setup.bash
    echo "ROS2 Vicon workspace setup complete!"
}

run_mavproxy() {
    mavproxy --master=/dev/ttyUSB0 --baudrate=230400 --out=udp:127.0.0.1:14550 --out=udp:100.98.109.70:14550 --aircraft=test
}

run_vicon() {
    gnome-terminal -- bash -c "cd ~/Documents/drone_position_hold_Vicon/ros2_ws; source install/setup.bash; ros2 launch mocap4r2_vicon_driver mocap4r2_vicon_driver_launch.py; exec bash"
    sleep 3
    gnome-terminal -- bash -c "cd ~/Documents/drone_position_hold_Vicon/ros2_ws; source install/setup.bash; ros2 lifecycle set /mocap4r2_vicon_driver_node activate; exec bash"
}

run_optitrack() {
	source_ros
	taskset -c 0,1 ros2 launch natnet_ros2 natnet_ros2.launch.py
}

run_publisher() {
    source_ros
    deactivate 2>/dev/null || true    # exit venv if active
    taskset -c 2,3 ros2 run position_publisher position_publisher
}

run_publisher_vicon() {
    source_ros_vicon
    deactivate 2>/dev/null || true    # exit venv if active
    env LD_LIBRARY_PATH=$LD_LIBRARY_PATH taskset -c 2,3 ros2 run position_publisher position_publisher
}

run_commander() {
    source_ros
    ros2 run position_publisher drone_commander
}

run_rt() {
    # 1. Set CPU Governor to Performance
    echo "Setting CPU governor to performance..."
    echo performance | sudo tee /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor > /dev/null
    cat /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor

    # 2. Set RT capability on system Python (one-time, persists until Python is updated)
    REAL_PYTHON=$(readlink -f $(which python3))
    if ! getcap "$REAL_PYTHON" | grep -q cap_sys_nice; then
        echo "Setting RT capability on $REAL_PYTHON..."
        sudo setcap cap_sys_nice=eip "$REAL_PYTHON"
    else
        echo "RT capability already set on $REAL_PYTHON"
    fi
}

export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:$HOME/Documents/drone_position_hold/ros2_ws/src/natnet_ros2/deps/NatNetSDK/lib

export ROS_DOMAIN_ID=42
export ROS_LOCALHOST_ONLY=1
