# New Pi setup for the drone pipeline

Turns a freshly flashed Raspberry Pi into a working drone pipeline Pi with one
script: it installs ROS 2 Jazzy and MAVProxy, builds the OptiTrack and Vicon ROS
workspaces, and installs `drone_pipeline`.

## What's in this folder

| Path | What it is |
|---|---|
| `setup.sh` | The script you run. Does everything below, in order |
| `drone_pipeline/` | The pipeline itself (`install.sh`, services, the `drone` command) |
| `workspaces/drone_position_hold/src` | ROS source code: `position_publisher`, `natnet_ros2` (OptiTrack) |
| `workspaces/drone_position_hold_Vicon/src` | ROS source code: Vicon driver |
| `files/drone_env.sh` | Shell shortcuts, loaded from `~/.bashrc` |
| `files/add_wifi.sh` | Saves a WiFi network (used for the Vicon WiFi) |
| `files/99-cubepilot.rules` | Gives the flight controller's USB port a fixed name |

## Before you start

1. **Hardware:** a Raspberry Pi 5 (or another 4-core Pi), an SD card (32 GB or
   more recommended), a monitor and keyboard for the first boot, the RFD900x radio,
   and for OptiTrack an ethernet cable to the Motive PC.
2. **Flash the SD card:** in Raspberry Pi Imager choose your Pi model, then
   Other general-purpose OS -> Ubuntu -> **Ubuntu Desktop 24.04 LTS (64-bit)**.
3. **First boot:** with the monitor and keyboard, go through the setup screens.
   Create your user (any name works; `straindronenew` matches the other docs) and
   connect to a WiFi network **with internet**.
4. **SSH (optional, to work from your PC):** in a terminal on the Pi:
   ```bash
   sudo apt update && sudo apt install -y openssh-server
   hostname -I        # the Pi's IP address
   ```
   For remote access from anywhere, also install Tailscale:
   `curl -fsSL https://tailscale.com/install.sh | sh` then `sudo tailscale up`.
5. **Check the settings** in `drone_pipeline/pipeline.conf` (you can also do this
   on the Pi before running `setup.sh`): `MOTIVE_IP`, `PI_MOCAP_IP`, `VICON_HOST`,
   `VICON_BODY`, `RADIO_DEV`, `MAVPROXY_EXTRA_OUTS`. You don't need to change the
   username or folder settings; `setup.sh` fills those in.
6. **Motive PC (OptiTrack):** its ethernet adapter must have the address
   `192.168.50.1`, subnet mask `255.255.255.0` (Windows Settings -> Network &
   internet -> Ethernet -> IP assignment -> Manual). In Motive set
   Streaming -> Local Interface to `192.168.50.1`, and allow Motive through Windows
   Firewall (tick **Public**).
7. **Vicon:** have the ASPEN-VICON WiFi password ready.

## Get the folder onto the Pi

Use the `new_pi_setup.tar.gz` file: it keeps Linux file permissions.

On the Pi, open Firefox, sign in to GitHub (the repo is private), open the repo,
click `new_pi_setup.tar.gz`, then **Download**. Then move it to your home folder:
```bash
mv ~/Downloads/new_pi_setup.tar.gz ~/
```
Or download it on a PC and copy it over with a USB stick
(`cp /media/$USER/<stick-name>/new_pi_setup.tar.gz ~/`) or with
`scp new_pi_setup.tar.gz <user>@<pi-ip>:~/`.

## Run it

On the Pi (desktop terminal, or `ssh <user>@<pi-ip>`):
```bash
cd ~
tar xzf new_pi_setup.tar.gz
cd new_pi_setup
bash setup.sh
```
- Run it as yourself, **not** with `sudo`. It asks for your password when needed,
  possibly more than once.
- It takes a long time (the Vicon SDK build is the slowest part). Keep the terminal
  or SSH session open until it prints **Setup finished**.
- Add `--enable-boot` (`bash setup.sh --enable-boot`) to start the OptiTrack
  pipeline automatically at every boot.
- If it stops with an error, fix the cause and run `bash setup.sh` again; finished
  steps are skipped or redone harmlessly.

## After it finishes

```bash
sudo reboot
sudo bash ~/add_wifi.sh "ASPEN-VICON"   # Vicon only; asks for the WiFi password
drone start && drone check              # or: drone start vicon && drone check
```
Plug in the radio (and the ethernet cable for OptiTrack) before `drone start`.
Every line of `drone check` should say OK. See `drone_pipeline/README.md` for all
`drone` commands.
