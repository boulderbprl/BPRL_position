#!/bin/bash
# Sets up a brand-new Raspberry Pi (Ubuntu 24.04 Desktop, arm64) to run the drone
# pipeline: ROS 2 Jazzy, MAVProxy, both ROS workspaces, then drone_pipeline.
#
#   bash setup.sh [--enable-boot]
#
# Run as your normal user, not with sudo; it asks for your password when needed.
# --enable-boot starts the OptiTrack pipeline automatically at every boot.
# Safe to rerun: steps that are already done are skipped or redone harmlessly.
set -euo pipefail

[ "$(id -u)" -ne 0 ] || { echo "run as your normal user: bash setup.sh (not sudo)" >&2; exit 1; }
for arg in "$@"; do
    case "$arg" in
        --enable-boot) ;;
        *) echo "unknown option: $arg" >&2; exit 2 ;;
    esac
done

HERE=$(cd "$(dirname "$0")" && pwd)
WS=$HOME/Documents/drone_position_hold/ros2_ws
VWS=$HOME/Documents/drone_position_hold_Vicon/ros2_ws

step() { printf '\n\e[1m== %s\e[0m\n' "$*"; }

# A freshly installed Ubuntu runs automatic updates in the background for a
# while after first boot, holding the apt lock. Wait for them instead of failing.
wait_for_apt() {
    while sudo fuser /var/lib/dpkg/lock-frontend /var/lib/dpkg/lock /var/lib/apt/lists/lock >/dev/null 2>&1; do
        echo "  waiting for background updates to finish (apt is locked)..."
        sleep 10
    done
}
APT="sudo apt-get -o DPkg::Lock::Timeout=900"

# ---------------------------------------------------------------------------
step "Checks"
. /etc/os-release
[ "$VERSION_ID" = 24.04 ] || { echo "needs Ubuntu 24.04 (this is $PRETTY_NAME)" >&2; exit 1; }
[ "$(uname -m)" = aarch64 ] || { echo "needs 64-bit (arm64) Ubuntu" >&2; exit 1; }
[ "$(nproc)" -ge 4 ] || { echo "needs a 4-core Pi (the pipeline reserves CPU 3)" >&2; exit 1; }
getent hosts packages.ros.org >/dev/null || { echo "no internet connection" >&2; exit 1; }
sudo -v
echo "  Ubuntu $VERSION_ID, $(uname -m), $(nproc) cores, user $USER"

# Files copied through Windows can have CRLF line endings, which break bash.
find "$HERE/files" "$HERE/drone_pipeline" -type f -exec sed -i 's/\r$//' {} +

# ---------------------------------------------------------------------------
step "Workspaces and shell files"
mkdir -p "$WS" "$VWS"
copy_src() {
    if [ -d "$2/src" ]; then
        echo "  keeping existing $2/src"
    else
        cp -r "$1/src" "$2/"
        echo "  $2/src"
    fi
}
copy_src "$HERE/workspaces/drone_position_hold" "$WS"
copy_src "$HERE/workspaces/drone_position_hold_Vicon" "$VWS"
# Loose scripts next to src (plotter, commander, disturbance forwarder, DDS config)
for f in "$HERE"/workspaces/drone_position_hold/*; do
    [ -f "$f" ] || continue
    [ -e "$WS/${f##*/}" ] || cp "$f" "$WS/"
done
chmod +x "$WS"/*.py

# Executable bits are lost if this folder went through Windows.
find "$WS/src" "$VWS/src" -type f \( -name '*.sh' -o -path '*/scripts/*' -o -name node_module.py \
    -o -path '*/position_publisher/position_publisher/*.py' \) -exec chmod +x {} +

[ -e "$HOME/drone_env.sh" ] || install -m 644 "$HERE/files/drone_env.sh" "$HOME/drone_env.sh"
install -m 755 "$HERE/files/add_wifi.sh" "$HOME/add_wifi.sh"
grep -qF 'source ~/drone_env.sh' ~/.bashrc || echo 'source ~/drone_env.sh' >> ~/.bashrc

# ---------------------------------------------------------------------------
step "Radio access"
sudo usermod -aG dialout "$USER"
sudo install -m 644 "$HERE/files/99-cubepilot.rules" /etc/udev/rules.d/
sudo udevadm control --reload
sudo udevadm trigger

# ---------------------------------------------------------------------------
step "ROS 2 Jazzy and system packages"
wait_for_apt
$APT update
$APT install -y software-properties-common curl git
wait_for_apt
sudo add-apt-repository -y universe
if ! dpkg -s ros2-apt-source >/dev/null 2>&1; then
    v=$(curl -s https://api.github.com/repos/ros-infrastructure/ros-apt-source/releases/latest \
        | grep -F tag_name | awk -F\" '{print $4}')
    curl -L -o /tmp/ros2-apt-source.deb \
        "https://github.com/ros-infrastructure/ros-apt-source/releases/download/${v}/ros2-apt-source_${v}.${VERSION_CODENAME}_all.deb"
    wait_for_apt
    sudo dpkg -i /tmp/ros2-apt-source.deb
    wait_for_apt
    $APT update
fi
$APT install -y ros-jazzy-desktop ros-dev-tools \
    ros-jazzy-mavros ros-jazzy-mavros-extras ros-jazzy-mavros-msgs \
    python3-venv python3-pip python3-numpy python3-scipy libcap2-bin \
    libboost-thread-dev libboost-date-time-dev libboost-chrono-dev
sudo /opt/ros/jazzy/lib/mavros/install_geographiclib_datasets.sh

# ---------------------------------------------------------------------------
step "MAVProxy and pymavlink"
# pymavlink for the system Python (position_publisher runs on it)
pip install --user --break-system-packages pymavlink
# MAVProxy in its own venv (the `mavproxy` alias in drone_env.sh activates it)
[ -d "$HOME/mavlink_env" ] || python3 -m venv "$HOME/mavlink_env"
"$HOME/mavlink_env/bin/pip" install mavproxy pymavlink

# ---------------------------------------------------------------------------
step "Build the OptiTrack workspace"
set +u   # ROS setup scripts use unset variables
. /opt/ros/jazzy/setup.bash
set -u
[ -f /etc/ros/rosdep/sources.list.d/20-default.list ] || sudo rosdep init
rosdep update
cd "$WS"
rosdep install --from-paths src --ignore-src -y --skip-keys "mocap4r2_vicon_driver" || true
colcon build --symlink-install

# ---------------------------------------------------------------------------
step "Build the Vicon workspace (builds the Vicon SDK; slow)"
cd "$VWS"
rosdep install --from-paths src --ignore-src -y || true
if ! MAKEFLAGS=-j3 colcon build --symlink-install; then
    echo "WARNING: Vicon workspace failed to build - OptiTrack mode still works," >&2
    echo "         'drone start vicon' will not until it builds." >&2
fi

# ---------------------------------------------------------------------------
step "Library paths"
# run_rt (drone_env.sh) sets cap_sys_nice on python3, which makes the linker
# ignore LD_LIBRARY_PATH, so workspace libraries must be in /etc/ld.so.conf.d.
printf '%s\n' /opt/ros/jazzy/lib /opt/ros/jazzy/lib/aarch64-linux-gnu \
    | sudo tee /etc/ld.so.conf.d/ros2-aarch64.conf >/dev/null
printf '%s\n' "$WS/src/natnet_ros2/deps/NatNetSDK/lib" "$WS/install/natnet_ros2/lib" \
    "$WS/install/mocap4r2_msgs/lib" \
    | sudo tee /etc/ld.so.conf.d/drone_ws.conf >/dev/null
# mocap4r2_msgs comes from drone_ws.conf (same messages in both workspaces)
V=$VWS/install
printf '%s\n' "$V/mocap4r2_control/lib" "$V/mocap4r2_control_msgs/lib" "$V/mocap4r2_marker_viz_srvs/lib" \
    "$V/mocap4r2_robot_gt/lib" "$V/mocap4r2_robot_gt_msgs/lib" "$V/mocap4r2_vicon_driver/lib" \
    | sudo tee /etc/ld.so.conf.d/drone_ws_vicon.conf >/dev/null
sudo ldconfig

# ---------------------------------------------------------------------------
step "Drone pipeline"
# Point the pipeline at this user's home folder, whatever the username is.
sed -i -e "s|^DRONE_USER=.*|DRONE_USER=$USER|" \
    -e "s|^ROS_WS=.*|ROS_WS=$WS|" \
    -e "s|^VICON_WS=.*|VICON_WS=$VWS|" \
    -e "s|^FLIGHT_LOG_DIR=.*|FLIGHT_LOG_DIR=$HOME/Documents/drone_position_hold/flight_logs|" \
    "$HERE/drone_pipeline/pipeline.conf"
sudo bash "$HERE/drone_pipeline/install.sh" "$@"

# ---------------------------------------------------------------------------
step "Setup finished"
cat <<EOF
Next:
  1. sudo reboot
  2. Vicon only:  sudo bash ~/add_wifi.sh "ASPEN-VICON"
  3. Plug in the RFD900x radio (and the ethernet cable to the Motive PC), then:
       drone start && drone check
EOF
