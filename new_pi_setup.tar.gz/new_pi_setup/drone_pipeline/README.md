# Isolated drone pipeline

Runs `natnet -> position_publisher -> MAVProxy -> RFD900x` on **CPU 3 only**,
under systemd, with SCHED_FIFO priorities and automatic restart. CPUs 0-2 run
everything else (desktop, ssh, WiFi, tailscale, plotting) normally.

```
 Motive PC ──eth0 (static, no default route)──┐
                                              ▼
 ┌──────────── CPU 3 (isolated, drone.slice) ─────────────────────┐
 │ drone-natnet    RR 70    NatNet → /crashDrone/pose             │
 │ drone-publisher FIFO 50/80  pose → VISION_* MAVLink            │
 │                          + /crashDrone/state (pos + vel)       │
 │ drone-mavproxy  FIFO 60  udp:127.0.0.1:14550 ↔ /dev/ttyUSB0    │
 │ (eth0 IRQs + packet processing stay on CPUs 0-2)               │
 └────────────────────────────────────────────────────────────────┘
          │ ROS 2, localhost only (shared memory)
          ▼
 CPUs 0-2: plotter_ros2.py, drone_commander, ros2 bag, rqt, WiFi, ...
```

### Vicon mode

`drone start vicon` swaps the mocap source; MAVProxy and position_publisher are
the same services as above.

```
 Vicon server ──WiFi (e.g. ASPEN-VICON)──┐
                                         ▼
 ┌──────────── CPU 3 (isolated, drone.slice) ─────────────────────┐
 │ drone-vicon-driver FIFO 70  Vicon DataStream → /rigid_bodies   │
 │ drone-vicon-relay  FIFO 65  VICON_BODY → /crashDrone/pose      │
 │ drone-publisher, drone-mavproxy (as above)                     │
 └────────────────────────────────────────────────────────────────┘
```

The relay also configures and activates the Vicon driver (no `ros2 lifecycle set`
needed), waits while the Vicon server is unreachable, re-activates the driver if it
restarts, and drops occluded frames. Like OptiTrack mode, positions go to the FC
unrotated: the Vicon world frame must already be set up as NED. WiFi interrupts stay
on CPUs 0-2, so Vicon packets are received off the RT core.

## How the isolation works

| Layer | What | Where |
|---|---|---|
| Kernel | `isolcpus=domain,managed_irq,3 rcu_nocbs=3 irqaffinity=0-2` | `/boot/firmware/cmdline.txt` |
| cgroups | `system.slice`, `user.slice`, `init.scope` → CPUs 0-2; `drone.slice` → CPU 3 | `systemctl set-property` |
| IRQs | all IRQs + RPS (eth0, WiFi, USB, SD) → 0-2; governor = performance | `cpu-setup.sh` (boot, before natnet, on eth0 up) |
| DDS | `ROS_AUTOMATIC_DISCOVERY_RANGE=LOCALHOST`, domain 42: ROS traffic never goes on eth0 or WiFi | `pipeline.conf` |

## Install

1. Edit `pipeline.conf`: set the mocap IPs (`PI_MOCAP_IP`, `MOTIVE_IP`), `RADIO_DEV`
   (use `/dev/serial/by-id/...` if possible) and `MAVPROXY_EXTRA_OUTS` for a ground station.
2. Copy over and install:
   ```bash
   scp -r drone_pipeline straindronenew@100.97.120.117:~/
   ssh -t straindronenew@100.97.120.117 'sudo bash ~/drone_pipeline/install.sh'
   sudo reboot
   ```
   `--enable-boot` starts the pipeline at boot. Rerun after changing CPU or priority settings.
3. Rebuild `position_publisher` (it now publishes `/crashDrone/state`):
   `colcon build --packages-select position_publisher`
4. On the Motive PC: give the ethernet adapter `MOTIVE_IP`/24, set
   Streaming → Local Interface to that IP, and allow Motive through Windows
   Firewall on that network.
5. For Vicon: build `VICON_WS` (`colcon build --symlink-install`), check `VICON_HOST`
   and `VICON_BODY` in `pipeline.conf`, and save the Vicon WiFi on the Pi
   (`sudo nmcli device wifi connect ASPEN-VICON password ...`).

## Use

```bash
drone start            # OptiTrack pipeline (replaces run_optitrack / run_mavproxy / run_publisher)
drone start vicon      # Vicon pipeline (replaces run_vicon / run_mavproxy / run_publisher_vicon)
drone check            # isolation, network, data rates for the running mode
drone radio            # rate sent to the radio (kbit/s) + whether the radio keeps up
drone status           # running mode; which CPU and scheduling policy every thread has
drone logs [publisher] # follow logs (vicon-relay shows lifecycle + body problems)
drone restart natnet   # one service: natnet, vicon-driver, vicon-relay, mavproxy, publisher
drone stop
drone enable vicon     # start Vicon mode at boot (plain `drone enable` = OptiTrack)
```

`drone start vicon` while OptiTrack is running (or the other way round) stops the
running mode first; only one mocap source ever publishes `/crashDrone/pose`.

Plotting or commanding from a terminal (runs on CPUs 0-2 automatically):

```bash
eval "$(drone env)"    # same ROS domain / discovery range as the pipeline
ros2 topic echo /crashDrone/state
ros2 bag record /crashDrone/state /crashDrone/pose
ros2 run position_publisher drone_commander
```

`/crashDrone/state` is `nav_msgs/Odometry` at mocap rate: `pose` is the mocap pose,
`twist.twist.linear` is the filtered velocity in the **world (NED) frame**, NaN until valid.

Don't run the old `run_mavproxy` / `run_publisher` / `run_vicon` functions while the
services are up: they fight over the radio, UDP port 14550 and `/crashDrone/pose`.

## Undo

`sudo bash uninstall.sh && sudo reboot`
