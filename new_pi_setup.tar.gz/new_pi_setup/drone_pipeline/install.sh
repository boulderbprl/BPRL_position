#!/bin/bash
# Install the isolated drone pipeline on the Pi.
#
#   sudo bash install.sh [--enable-boot] [--no-kernel] [--no-network]
#
#   --enable-boot  start the pipeline automatically at boot
#   --no-kernel    leave /boot/firmware/cmdline.txt alone (no isolcpus)
#   --no-network   leave the mocap ethernet configuration alone
#
# Safe to rerun after editing /etc/drone-pipeline/pipeline.conf.
set -euo pipefail

ENABLE_BOOT=0 DO_KERNEL=1 DO_NETWORK=1
for arg in "$@"; do
    case "$arg" in
        --enable-boot) ENABLE_BOOT=1 ;;
        --no-kernel)   DO_KERNEL=0 ;;
        --no-network)  DO_NETWORK=0 ;;
        *) echo "unknown option: $arg" >&2; exit 2 ;;
    esac
done

[ "$(id -u)" -eq 0 ] || { echo "run with sudo" >&2; exit 1; }

SRC=$(cd "$(dirname "$0")" && pwd)
CONF=/etc/drone-pipeline/pipeline.conf
LIB=/usr/local/lib/drone-pipeline
REBOOT_NEEDED=0

step() { printf '\n\e[1m== %s\e[0m\n' "$*"; }

# Files copied from Windows may have CRLF line endings.
strip_cr() { sed -i 's/\r$//' "$@"; }

# ---------------------------------------------------------------------------
step "Configuration"
install -d -m 755 /etc/drone-pipeline
if [ -e "$CONF" ]; then
    echo "keeping existing $CONF"
    # Settings added since it was installed get their defaults appended.
    while IFS= read -r line; do
        key=${line%%=*}
        if ! grep -q "^$key=" "$CONF"; then
            printf '%s\n' "$line" >> "$CONF"
            echo "  added $line"
        fi
    done < <(sed 's/\r$//' "$SRC/pipeline.conf" | grep -E '^[A-Z_]+=')
else
    install -m 644 "$SRC/pipeline.conf" "$CONF"
    echo "installed $CONF"
fi
strip_cr "$CONF"
set -a; . "$CONF"; set +a

id "$DRONE_USER" >/dev/null
[ -d "/opt/ros/$ROS_DISTRO" ] || { echo "ROS $ROS_DISTRO not found" >&2; exit 1; }
[ -x "$ROS_WS/install/position_publisher/lib/position_publisher/position_publisher" ] \
    || { echo "position_publisher not built in $ROS_WS (colcon build first)" >&2; exit 1; }
[ -x "$VICON_WS/install/mocap4r2_vicon_driver/lib/mocap4r2_vicon_driver/mocap4r2_vicon_driver_main" ] \
    || echo "WARNING: Vicon driver not built in $VICON_WS - 'drone start vicon' will fail until it is" >&2

if [ -z "$MAVPROXY_BIN" ]; then
    MAVPROXY_BIN=$(sudo -u "$DRONE_USER" -i bash -ic 'command -v mavproxy.py || command -v mavproxy' 2>/dev/null \
        | grep '^/' | tail -1 || true)
    # `mavproxy` is often an alias that activates ~/mavlink_env, which command -v can't see.
    venv_mavproxy=$(getent passwd "$DRONE_USER" | cut -d: -f6)/mavlink_env/bin/mavproxy.py
    [ -n "$MAVPROXY_BIN" ] || { [ -x "$venv_mavproxy" ] && MAVPROXY_BIN=$venv_mavproxy; }
    if [ -n "$MAVPROXY_BIN" ]; then
        sed -i "s|^MAVPROXY_BIN=.*|MAVPROXY_BIN=$MAVPROXY_BIN|" "$CONF"
        echo "MAVProxy: $MAVPROXY_BIN"
    else
        echo "WARNING: mavproxy not found for $DRONE_USER - set MAVPROXY_BIN in $CONF" >&2
    fi
fi

install -d -o "$DRONE_USER" -g "$DRONE_USER" "$FLIGHT_LOG_DIR"
usermod -aG dialout "$DRONE_USER"

# ---------------------------------------------------------------------------
step "Scripts and systemd units"
install -d -m 755 "$LIB"
install -m 644 "$SRC/lib/ros-env.sh" "$SRC/lib/vicon-relay.py" "$SRC/lib/radio-status.py" "$LIB/"
install -m 755 "$SRC"/lib/run-*.sh "$SRC/lib/cpu-setup.sh" "$LIB/"
install -m 755 "$SRC/bin/drone" /usr/local/bin/drone
strip_cr "$LIB"/* /usr/local/bin/drone

for unit in "$SRC"/systemd/*; do
    dest=/etc/systemd/system/$(basename "$unit")
    sed -e 's/\r$//' \
        -e "s|@DRONE_USER@|$DRONE_USER|g" \
        -e "s|@RT_CPU@|$RT_CPU|g" \
        -e "s|@NATNET_RT_PRIO@|$NATNET_RT_PRIO|g" \
        -e "s|@MAVPROXY_RT_PRIO@|$MAVPROXY_RT_PRIO|g" \
        -e "s|@PUBLISHER_RT_PRIO@|$PUBLISHER_RT_PRIO|g" \
        -e "s|@VICON_RT_PRIO@|$VICON_RT_PRIO|g" \
        -e "s|@VICON_RELAY_RT_PRIO@|$VICON_RELAY_RT_PRIO|g" \
        "$unit" > "$dest"
    echo "  $dest"
done

# ---------------------------------------------------------------------------
step "Userspace CPU partition (cgroup cpusets, live now)"
# Everything outside drone.slice is confined to the housekeeping cores. This
# holds even if someone runs `taskset -c 3 ...` from a terminal.
for unit in system.slice user.slice init.scope; do
    systemctl set-property "$unit" AllowedCPUs="$HOUSEKEEPING_CPUS"
    echo "  $unit -> CPUs $HOUSEKEEPING_CPUS"
done

# irqbalance would undo the IRQ pinning in cpu-setup.sh.
if systemctl list-unit-files irqbalance.service >/dev/null 2>&1 \
        && systemctl is-enabled -q irqbalance.service 2>/dev/null; then
    systemctl disable --now irqbalance.service
    echo "  disabled irqbalance"
fi

# ---------------------------------------------------------------------------
if [ "$DO_KERNEL" -eq 1 ]; then
    step "Kernel isolation of CPU $RT_CPU"
    CMDLINE=/boot/firmware/cmdline.txt
    [ -f "$CMDLINE" ] || { echo "$CMDLINE not found" >&2; exit 1; }
    # isolcpus:    scheduler never places other tasks or unbound kthreads on RT_CPU
    # rcu_nocbs:   RCU callbacks run on the housekeeping cores
    # irqaffinity: default IRQ affinity; cpu-setup.sh then moves only the mocap NIC over
    # (no nohz_full: the tick only stops with one runnable task, and three
    #  processes share this core, so it would only add syscall overhead)
    want="isolcpus=domain,managed_irq,$RT_CPU rcu_nocbs=$RT_CPU irqaffinity=$HOUSEKEEPING_CPUS"
    current=$(tr -d '\r\n' < "$CMDLINE")
    stripped=$(tr ' ' '\n' <<<"$current" | grep -vE '^(isolcpus|rcu_nocbs|irqaffinity|nohz_full)=' \
        | grep -v '^$' | tr '\n' ' ')
    new="${stripped% } $want"
    if [ "$new" != "$current" ]; then
        cp "$CMDLINE" "$CMDLINE.bak-$(date +%Y%m%d-%H%M%S)"
        printf '%s\n' "$new" > "$CMDLINE"
        echo "  $CMDLINE: $new"
        REBOOT_NEEDED=1
    else
        echo "  already set"
    fi
fi

# ---------------------------------------------------------------------------
if [ "$DO_NETWORK" -eq 1 ]; then
    step "Mocap ethernet ($MOCAP_IFACE = $PI_MOCAP_IP/$MOCAP_PREFIX, no default route)"
    nm_manages_iface() {
        systemctl -q is-active NetworkManager 2>/dev/null \
            && nmcli -t -f DEVICE,STATE device 2>/dev/null | grep -q "^$MOCAP_IFACE:" \
            && ! nmcli -t -f DEVICE,STATE device | grep -q "^$MOCAP_IFACE:unmanaged"
    }
    if nm_manages_iface; then
        # Other wired profiles (e.g. netplan-eth0, DHCP) would fight for eth0.
        # Profiles that come from netplan can't always be modified through nmcli
        # ("netplan generate failed"), so this is best effort; mocap-eth's higher
        # autoconnect-priority makes NetworkManager pick it on eth0 regardless.
        while IFS=: read -r uuid type; do
            [ "$type" = 802-3-ethernet ] || continue
            name=$(nmcli -g connection.id connection show "$uuid")
            ifc=$(nmcli -g connection.interface-name connection show "$uuid")
            if [ "$name" != mocap-eth ] && { [ -z "$ifc" ] || [ "$ifc" = "$MOCAP_IFACE" ]; }; then
                if nmcli connection modify "$uuid" connection.autoconnect no 2>/dev/null; then
                    echo "  autoconnect off for '$name'"
                else
                    echo "  left '$name' alone (mocap-eth has priority over it)"
                fi
            fi
        done < <(nmcli -t -f UUID,TYPE connection show)
        # Written as a keyfile, not with `nmcli connection add`: on Ubuntu 24.04
        # that goes through netplan, which fails on this Pi.
        nmcli connection delete mocap-eth >/dev/null 2>&1 || true
        keyfile=/etc/NetworkManager/system-connections/mocap-eth.nmconnection
        cat > "$keyfile" <<EOF
[connection]
id=mocap-eth
uuid=$(cat /proc/sys/kernel/random/uuid)
type=ethernet
interface-name=$MOCAP_IFACE
autoconnect=true
autoconnect-priority=100

[ethernet]

[ipv4]
method=manual
address1=$PI_MOCAP_IP/$MOCAP_PREFIX
never-default=true
ignore-auto-dns=true

[ipv6]
method=disabled
EOF
        chmod 600 "$keyfile"
        nmcli connection reload
        echo "  NetworkManager profile 'mocap-eth' created ($keyfile)"
        nmcli connection up mocap-eth >/dev/null 2>&1 \
            && echo "  mocap-eth up" || echo "  mocap-eth will come up when the cable is connected"
        install -m 755 "$SRC/lib/90-drone-mocap-irq" /etc/NetworkManager/dispatcher.d/
        strip_cr /etc/NetworkManager/dispatcher.d/90-drone-mocap-irq
    else
        cat > /etc/netplan/60-drone-mocap.yaml <<EOF
# Mocap link: static, never the default route, never blocks boot.
network:
  version: 2
  ethernets:
    $MOCAP_IFACE:
      dhcp4: false
      dhcp6: false
      link-local: []
      optional: true
      addresses: [$PI_MOCAP_IP/$MOCAP_PREFIX]
EOF
        chmod 600 /etc/netplan/60-drone-mocap.yaml
        netplan generate
        echo "  wrote /etc/netplan/60-drone-mocap.yaml (applies on reboot)"
        echo "  check no other netplan file enables dhcp4 on $MOCAP_IFACE:"
        grep -l "$MOCAP_IFACE" /etc/netplan/*.yaml | sed 's/^/    /' || true
        REBOOT_NEEDED=1
    fi
fi

# ---------------------------------------------------------------------------
step "Enable"
systemctl daemon-reload
systemctl enable --now drone-cpu-setup.service >/dev/null
systemctl restart drone-cpu-setup.service
if [ "$ENABLE_BOOT" -eq 1 ]; then
    systemctl enable drone-pipeline.target
    echo "  pipeline starts at boot"
else
    echo "  pipeline NOT started at boot (drone enable to change)"
fi

step "Done"
if [ "$REBOOT_NEEDED" -eq 1 ]; then
    echo "Reboot to apply kernel/network changes:  sudo reboot"
    echo "Then:  drone start && drone check"
else
    echo "drone start && drone check"
fi
