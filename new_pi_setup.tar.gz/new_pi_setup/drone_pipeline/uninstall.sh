#!/bin/bash
# Remove the isolated drone pipeline and give CPU 3 back to the system.
#   sudo bash uninstall.sh
# Leaves /etc/drone-pipeline/pipeline.conf and the 'mocap-eth' network profile
# (remove with: sudo nmcli connection delete mocap-eth).
set -uo pipefail
[ "$(id -u)" -eq 0 ] || { echo "run with sudo" >&2; exit 1; }

systemctl disable --now drone-pipeline.target drone-pipeline-vicon.target drone-cpu-setup.service 2>/dev/null
systemctl stop drone-natnet.service drone-vicon-driver.service drone-vicon-relay.service \
    drone-mavproxy.service drone-publisher.service 2>/dev/null
rm -f /etc/systemd/system/drone-{pipeline.target,pipeline-vicon.target,cpu-setup.service,natnet.service}
rm -f /etc/systemd/system/drone-{vicon-driver.service,vicon-relay.service,mavproxy.service,publisher.service}
rm -f /etc/systemd/system/drone.slice
for unit in system.slice user.slice init.scope; do
    rm -f "/etc/systemd/system.control/$unit.d/50-AllowedCPUs.conf"
done
systemctl daemon-reload
for unit in system.slice user.slice init.scope; do
    systemctl set-property --runtime "$unit" AllowedCPUs=
done

rm -rf /usr/local/lib/drone-pipeline /usr/local/bin/drone
rm -f /etc/NetworkManager/dispatcher.d/90-drone-mocap-irq

CMDLINE=/boot/firmware/cmdline.txt
if grep -qE 'isolcpus=|rcu_nocbs=|irqaffinity=' "$CMDLINE"; then
    cp "$CMDLINE" "$CMDLINE.bak-$(date +%Y%m%d-%H%M%S)"
    tr -d '\r\n' < "$CMDLINE" | tr ' ' '\n' \
        | grep -vE '^(isolcpus|rcu_nocbs|irqaffinity)=' | grep -v '^$' \
        | paste -sd' ' > "$CMDLINE.new" && mv "$CMDLINE.new" "$CMDLINE"
    echo "Kernel isolation removed from $CMDLINE - reboot to apply."
fi
echo "Uninstalled."
