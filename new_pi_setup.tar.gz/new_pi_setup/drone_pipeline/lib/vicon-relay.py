#!/usr/bin/env python3
# Vicon /rigid_bodies -> crashDrone/pose, so position_publisher works the same
# with Vicon as with OptiTrack. Also takes the Vicon driver (a lifecycle node)
# through configure -> activate, and again whenever it restarts or loses the
# connection to the Vicon server.
import os
import socket

import rclpy
from geometry_msgs.msg import PoseStamped
from lifecycle_msgs.msg import State, Transition
from lifecycle_msgs.srv import ChangeState, GetState
from mocap4r2_msgs.msg import RigidBodies
from rclpy.node import Node

DRIVER = '/mocap4r2_vicon_driver_node'


class ViconRelay(Node):
    def __init__(self, body, vicon_host):
        super().__init__('vicon_relay')
        self.body = body
        host, _, port = vicon_host.rpartition(':')
        self.vicon_addr = (host, int(port))
        self.unreachable_logged = False
        self.body_seen = False
        self.pub = self.create_publisher(PoseStamped, 'crashDrone/pose', 10)
        self.create_subscription(RigidBodies, '/rigid_bodies', self.on_rigid_bodies, 10)

        self.get_state = self.create_client(GetState, DRIVER + '/get_state')
        self.change_state = self.create_client(ChangeState, DRIVER + '/change_state')
        self.request = None       # lifecycle call in flight, if any
        self.create_timer(1.0, self.keep_driver_active)
        self.get_logger().info(f"Relaying Vicon body '{body}' to crashDrone/pose")

    def on_rigid_bodies(self, msg):
        for rb in msg.rigidbodies:
            if rb.rigid_body_name == self.body:
                break
        else:
            names = ', '.join(rb.rigid_body_name for rb in msg.rigidbodies) or 'none'
            self.get_logger().warn(
                f"Vicon body '{self.body}' not streamed (got: {names}) - set VICON_BODY",
                throttle_duration_sec=5.0)
            return

        q = rb.pose.orientation
        # The SDK reports an occluded body as all zeros. A zero quaternion would
        # also make position_publisher divide by zero, so drop it either way.
        if q.x == q.y == q.z == q.w == 0.0:
            self.get_logger().warn('Vicon body occluded', throttle_duration_sec=1.0)
            return
        if not self.body_seen:
            self.body_seen = True
            self.get_logger().info(f"Receiving '{self.body}'")

        out = PoseStamped()
        out.header = msg.header
        out.pose = rb.pose
        self.pub.publish(out)

    # Lifecycle: unconfigured -> configure (connects to Vicon) -> inactive -> activate
    def keep_driver_active(self):
        if self.request is not None and not self.request.done():
            return
        if not self.get_state.service_is_ready():
            return
        self.request = self.get_state.call_async(GetState.Request())
        self.request.add_done_callback(self.on_driver_state)

    def on_driver_state(self, future):
        state = future.result().current_state.id
        if state == State.PRIMARY_STATE_UNCONFIGURED:
            # The driver aborts if configure can't connect, so wait until the
            # Vicon server answers.
            if not self.vicon_reachable():
                return
            transition = Transition.TRANSITION_CONFIGURE
        elif state == State.PRIMARY_STATE_INACTIVE:
            transition = Transition.TRANSITION_ACTIVATE
        else:
            return
        self.get_logger().info(
            'Vicon driver: ' + ('configuring (connecting to Vicon)' if state == State.PRIMARY_STATE_UNCONFIGURED
                                else 'activating'))
        req = ChangeState.Request()
        req.transition.id = transition
        self.request = self.change_state.call_async(req)
        self.request.add_done_callback(self.on_transition_done)

    def vicon_reachable(self):
        try:
            socket.create_connection(self.vicon_addr, timeout=0.5).close()
        except OSError as e:
            if not self.unreachable_logged:
                self.unreachable_logged = True
                self.get_logger().warn(
                    f'Vicon server {self.vicon_addr[0]}:{self.vicon_addr[1]} not reachable ({e}) - '
                    'waiting (on the Vicon WiFi?)')
            return False
        if self.unreachable_logged:
            self.unreachable_logged = False
            self.get_logger().info('Vicon server reachable')
        return True

    def on_transition_done(self, future):
        if not future.result().success:
            self.get_logger().warn('Vicon driver transition failed (Vicon server reachable?) - retrying',
                                   throttle_duration_sec=10.0)


def main():
    rclpy.init()
    node = ViconRelay(os.environ.get('VICON_BODY', 'QuadPlane.QuadPlane'),
                      os.environ.get('VICON_HOST', '192.168.20.100:801'))
    try:
        rclpy.spin(node)
    except (KeyboardInterrupt, rclpy.executors.ExternalShutdownException):
        pass


if __name__ == '__main__':
    main()
