#!/bin/bash
# OptiTrack Motive (NatNet over MOCAP_IFACE) -> ROS 2 crashDrone/pose
. /usr/local/lib/drone-pipeline/ros-env.sh

if ! ip -4 addr show dev "$MOCAP_IFACE" 2>/dev/null | grep -q "inet $PI_MOCAP_IP/"; then
    echo "$MOCAP_IFACE does not have $PI_MOCAP_IP yet (cable unplugged?) - retrying" >&2
    exit 1
fi

exec ros2 launch natnet_ros2 natnet_ros2.launch.py \
    serverIP:="$MOTIVE_IP" \
    clientIP:="$PI_MOCAP_IP" \
    serverType:="$NATNET_SERVER_TYPE" \
    activate:=true
