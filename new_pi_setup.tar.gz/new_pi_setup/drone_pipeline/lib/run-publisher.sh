#!/bin/bash
# crashDrone/pose -> VISION_POSITION/SPEED_ESTIMATE -> MAVProxy
# Also publishes crashDrone/state (position + velocity) for plotting.
. /usr/local/lib/drone-pipeline/ros-env.sh

# Exec the entry point directly: `ros2 run` would leave an extra Python
# process sitting on the RT core.
exec "$ROS_WS/install/position_publisher/lib/position_publisher/position_publisher" \
    --ros-args -p "fc_rate_hz:=${FC_RATE_HZ:-30}"
