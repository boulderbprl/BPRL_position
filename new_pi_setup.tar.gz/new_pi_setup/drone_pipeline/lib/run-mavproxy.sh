#!/bin/bash
# RFD900x radio <-> MAVProxy -> udp:127.0.0.1:14550 (position_publisher)
set -a
. /etc/drone-pipeline/pipeline.conf
set +a

if [ -z "$MAVPROXY_BIN" ] || [ ! -x "$MAVPROXY_BIN" ]; then
    echo "MAVPROXY_BIN='$MAVPROXY_BIN' is not executable - set it in /etc/drone-pipeline/pipeline.conf" >&2
    exit 1
fi

if [ ! -e "$RADIO_DEV" ]; then
    echo "Waiting for radio at $RADIO_DEV ..." >&2
    while [ ! -e "$RADIO_DEV" ]; do sleep 1; done
    sleep 1   # let udev finish permissions
fi

args=(
    --master="$RADIO_DEV"
    --baudrate="$RADIO_BAUD"
    --out=udp:127.0.0.1:14550
    --out=udp:127.0.0.1:14551     # monitor port for `drone radio` (listen only)
    --aircraft="$MAVPROXY_AIRCRAFT"
    --non-interactive
)
for out in $MAVPROXY_EXTRA_OUTS; do
    args+=(--out="$out")
done
if [ -n "$MAVPROXY_STREAMRATE" ]; then
    args+=(--streamrate="$MAVPROXY_STREAMRATE")
fi

export PYTHONUNBUFFERED=1
cd "$FLIGHT_LOG_DIR" || exit 1    # MAVProxy writes <aircraft>/logs/... here
exec "$MAVPROXY_BIN" "${args[@]}"
