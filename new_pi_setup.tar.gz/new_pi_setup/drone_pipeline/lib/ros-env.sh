# Sourced (not executed): pipeline settings + ROS 2 environment.
set -a
. /etc/drone-pipeline/pipeline.conf
set +a
unset ROS_LOCALHOST_ONLY          # superseded by ROS_AUTOMATIC_DISCOVERY_RANGE in Jazzy
. "/opt/ros/$ROS_DISTRO/setup.bash"
. "$ROS_WS/install/setup.bash"
export PYTHONUNBUFFERED=1         # logs reach journald immediately
export RCUTILS_COLORIZED_OUTPUT=0
