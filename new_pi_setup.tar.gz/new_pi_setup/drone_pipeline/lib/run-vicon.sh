#!/bin/bash
# Vicon DataStream (over WiFi) -> ROS 2 /rigid_bodies
# Starts unconfigured; drone-vicon-relay configures and activates it.
. /usr/local/lib/drone-pipeline/ros-env.sh
. "$VICON_WS/install/setup.bash"

# Exec the driver directly: `ros2 launch` would leave a Python process on the RT core.
pkg=$VICON_WS/install/mocap4r2_vicon_driver
exec "$pkg/lib/mocap4r2_vicon_driver/mocap4r2_vicon_driver_main" --ros-args \
    -r __node:=mocap4r2_vicon_driver_node \
    --params-file "$pkg/share/mocap4r2_vicon_driver/config/mocap4r2_vicon_driver_params.yaml" \
    -p host_name:="$VICON_HOST"
