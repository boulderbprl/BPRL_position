#!/bin/bash
# Runs as root at boot, before natnet starts, and whenever the mocap NIC comes up.
# Keeps kernel work off RT_CPU, including the mocap NIC's interrupts and packet
# processing, which run on the housekeeping cores so they never preempt natnet.
set -u
set -a
. /etc/drone-pipeline/pipeline.conf
set +a

# "0-2,5" -> hex CPU mask
cpulist_to_mask() {
    local mask=0 part lo hi i
    for part in ${1//,/ }; do
        lo=${part%-*}; hi=${part#*-}
        for ((i = lo; i <= hi; i++)); do mask=$((mask | (1 << i))); done
    done
    printf '%x' "$mask"
}

rt_mask=$(cpulist_to_mask "$RT_CPU")
hk_mask=$(cpulist_to_mask "$HOUSEKEEPING_CPUS")

# Fixed clock: no frequency ramp latency (all Pi cores share one policy).
for gov in /sys/devices/system/cpu/cpufreq/policy*/scaling_governor; do
    echo performance > "$gov" 2>/dev/null || true
done

# systemd doesn't persist set-property for init.scope (system/user.slice keep theirs).
systemctl set-property --runtime init.scope AllowedCPUs="$HOUSEKEEPING_CPUS" 2>/dev/null || true

# Unbound kernel workqueues stay on the housekeeping cores.
echo "$hk_mask" > /sys/devices/virtual/workqueue/cpumask 2>/dev/null || true

# IRQs: all of them (mocap NIC, WiFi, USB, SD, ...) -> housekeeping. The mocap
# NIC's IRQs are found anyway so they can be reported and checked by `drone check`.
found_irqs=$(awk -v ifc="$MOCAP_IFACE" \
    '$NF ~ "^" ifc "([-_].*)?$" { sub(":", "", $1); printf "%s ", $1 }' /proc/interrupts)
mocap_irqs=" $found_irqs"
for dir in /proc/irq/[0-9]*; do
    irq=${dir##*/}
    if [[ "$mocap_irqs" == *" $irq "* ]]; then
        echo "$HOUSEKEEPING_CPUS" > "$dir/smp_affinity_list" 2>/dev/null || true
    else
        echo "$HOUSEKEEPING_CPUS" > "$dir/smp_affinity_list" 2>/dev/null || true
    fi
done

# Receive packet steering: packets from every NIC processed on housekeeping, never RT_CPU.
for net in /sys/class/net/*; do
    ifc=${net##*/}
    [ "$ifc" = lo ] && continue
    mask=$hk_mask
    for q in "$net"/queues/rx-*/rps_cpus; do
        [ -e "$q" ] && echo "$mask" > "$q" 2>/dev/null
    done
done

echo "cpu-setup: RT_CPU=$RT_CPU, $MOCAP_IFACE IRQs: ${found_irqs:-none (link down?)}"
exit 0
