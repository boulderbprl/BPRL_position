#!/bin/bash
# Vicon /rigid_bodies (VICON_BODY) -> crashDrone/pose; keeps the driver active.
. /usr/local/lib/drone-pipeline/ros-env.sh
. "$VICON_WS/install/setup.bash"

exec python3 /usr/local/lib/drone-pipeline/vicon-relay.py
