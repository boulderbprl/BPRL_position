"""Runs on the Pi: forwards the plotter's ROS topics to the Mac over UDP.

Each packet is one JSON object holding the pose and the latest controller, so a
plotter that starts late still gets the controller.

Position is sent as [forward, right, down] offsets from the commander's saved
point (POINT_FILE, written with [w] in the commander), in the drone's yaw frame:
yaw is rotated out, roll and pitch are not, so the Y-Z plot's axes stay level.
The Mac draws the drone's roll from the orientation, which is sent unchanged.
The zero is already removed, so the packet's zero is always all zeros. The file
is re-read whenever it changes, so pressing [w] again moves the zero without a
restart; nothing is sent until the file holds a point.
"""
import json
import math
import os
import socket

import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, DurabilityPolicy
from geometry_msgs.msg import PoseStamped
from scipy.spatial.transform import Rotation as R
from std_msgs.msg import String

# Same file and parser as the commander's [w] / [t], so the format always matches
from position_publisher.drone_commander import POINT_FILE, read_point_file

# ---- Forwarding configuration ------------------------------------------------
MAC_IP   = '100.101.238.71'  # Mac's address on the lab tailnet
MAC_PORT = 5102              # must match UDP_PORT in disturbance_plotter_mac.py
# ------------------------------------------------------------------------------


class DisturbanceForwarder(Node):
    def __init__(self):
        super().__init__('disturbance_forwarder')

        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.controller = None  # sent as null until the first controller message
        self.zero = None        # (n, e, d) from POINT_FILE, needed to send anything
        self.point_mtime = None # POINT_FILE's modification time when last read

        self.create_subscription(PoseStamped, 'crashDrone/pose', self.pose_callback, 10)
        # Latched by the bridge, so the controller published before this started
        # still arrives (the bridge only sends it when it changes)
        self.create_subscription(
            String, 'crashDrone/controller', self.controller_callback,
            QoSProfile(depth=1, durability=DurabilityPolicy.TRANSIENT_LOCAL))

        self.reload_point()
        self.create_timer(1.0, self.reload_point)   # picks up a new [w] within 1 s

        self.get_logger().info(f'Forwarding to {MAC_IP}:{MAC_PORT}, waiting for pose...')

    def controller_callback(self, msg: String):
        self.controller = msg.data

    def reload_point(self):
        """Re-read POINT_FILE if it changed since the last read."""
        try:
            mtime = os.stat(POINT_FILE).st_mtime
        except OSError:
            mtime = None    # no file (yet)
        if mtime == self.point_mtime:
            return
        self.point_mtime = mtime
        point = None if mtime is None else read_point_file(POINT_FILE)
        if point is None:
            if self.zero is not None:
                self.get_logger().warn(f'No readable point in {POINT_FILE} any more, '
                                       'sending stopped')
            self.zero = None
            return
        self.zero = list(point[:3])     # yaw is not used: yaw comes from each pose
        self.get_logger().info(f'Zero = saved point N={self.zero[0]:.3f}  '
                               f'E={self.zero[1]:.3f}  D={self.zero[2]:.3f}')

    def pose_callback(self, msg: PoseStamped):
        if self.zero is None:
            self.get_logger().warn(f'No saved point in {POINT_FILE} yet, '
                                   'press [w] in the commander',
                                   throttle_duration_sec=5.0)
            return

        p = msg.pose.position
        q = msg.pose.orientation
        if q.x == q.y == q.z == q.w == 0.0:
            return  # null mocap frame, which the bridge rejects too

        yaw = R.from_quat([q.x, q.y, q.z, q.w]).as_euler('ZYX')[0]
        north = p.x - self.zero[0]
        east = p.y - self.zero[1]
        forward = math.cos(yaw) * north + math.sin(yaw) * east
        right = -math.sin(yaw) * north + math.cos(yaw) * east

        packet = {
            't': msg.header.stamp.sec + msg.header.stamp.nanosec * 1e-9,
            'position': [forward, right, p.z - self.zero[2]],
            'orientation': [q.x, q.y, q.z, q.w],
            'controller': self.controller,
            'zero': [0.0, 0.0, 0.0],
        }
        try:
            self.sock.sendto(json.dumps(packet).encode(), (MAC_IP, MAC_PORT))
        except OSError as error:  # a tailnet drop shouldn't stop the forwarder
            self.get_logger().warn(f'Send failed: {error}', throttle_duration_sec=5.0)


def main():
    rclpy.init()
    node = DisturbanceForwarder()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.sock.close()
        node.destroy_node()
        rclpy.try_shutdown()


if __name__ == '__main__':
    main()
