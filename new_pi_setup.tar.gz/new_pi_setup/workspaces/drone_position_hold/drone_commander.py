#!/usr/bin/env python3
"""
Drone Commander — keyboard interface for the position_publisher bridge.

Run this in a SEPARATE terminal from position_publisher.

Killing or crashing this node:
  - does NOT affect the bridge process
  - does NOT interrupt mocap → FC data flow
  - does NOT change the flight controller's mode or position

BPRL_flight trajectory keys (single key, no Enter). The drone only acts on
point/circle while it is flying in POS_HOLD with mocap valid and an origin
set. Moving the roll, pitch or yaw stick cancels a trajectory; the throttle
stick raises/lowers it.
  [z]      Set origin = where the drone is now
  [g]      Go to the origin (N/E and yaw of the origin, current height)
  [p]      Point:  asks for N, E, D, yaw
  [c]      Circle: asks for radius, centre, ellipse, direction, speed
  [s] / space   Stop — drone holds position
  [w]      Save the drone's current position and yaw to the point file
  [t]      Travel to the point saved in the point file
  [1] / [2]     Save the drone's current position and yaw as point A / point B
  [b]      Fly back and forth between A and B (any key stops)
All positions are NED offsets from the origin in metres (D is positive
DOWN: 1 m above the origin is D = -1). Leaving an answer blank means "not
given" and the flight controller uses its default.

Yaw is typed and saved in degrees from North, clockwise seen from above
(East = 90), and sent to the flight controller in radians. It is an absolute
heading, not relative to the origin.

The point file (POINT_FILE) holds the absolute mocap position, so a saved
point stays at the same place in the room even after the origin is reset.
[t] converts it to an offset from the current origin before sending it.
Points A and B (POINT_A_FILE, POINT_B_FILE) work the same way. [b] sends
the next point once mocap shows the drone has stayed within ARRIVE_TOLERANCE
of the current one for SETTLE_TIME; a leg that takes longer than LEG_TIMEOUT (e.g. a stick input
cancelled it) ends the shuttle.

ArduPilot key:
  [a]      Goto zero (switches FC to Guided, sends position + yaw target)

  [q]      Quit this commander only
"""

import math
import os
import select
import sys
import time
import tty
import termios
import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, DurabilityPolicy
from geometry_msgs.msg import PoseStamped
from std_srvs.srv import Trigger
from std_msgs.msg import Float32MultiArray, Int32MultiArray

# BPRL_flight trajectory commands (MAV_CMD_USER_1..4) — see position_publisher.py
TRAJ_SET_ORIGIN = 31010
TRAJ_POINT      = 31011
TRAJ_CIRCLE     = 31012
TRAJ_STOP       = 31013

NAN = float('nan')

# Saved point for [w] / [t]: absolute mocap NED position [m] and yaw [deg]
POINT_FILE = os.path.expanduser('~/drone_saved_point.txt')
# Points for the [b] A <-> B shuttle, same format
POINT_A_FILE = os.path.expanduser('~/drone_point_a.txt')
POINT_B_FILE = os.path.expanduser('~/drone_point_b.txt')
ARRIVE_TOLERANCE = 0.15     # m, 3D distance that counts as "arrived"
SETTLE_TIME      = 3.0      # s it must stay within that, without leaving
LEG_TIMEOUT      = 30.0     # s allowed per leg before the shuttle gives up

# MAV_RESULT values the flight controller answers with
ACK_TEXT = {
    0: 'ACCEPTED',
    1: 'REJECTED for now — origin not set, not flying in POS_HOLD, no valid mocap '
       'position, or (set origin) a trajectory is running',
    2: 'DENIED — bad parameters: radius missing/out of range, offset too large, '
       'or height below the take-off floor',
    3: 'UNSUPPORTED — this flight controller does not know the command',
    4: 'FAILED — the flight controller did not process the command',
}


class DroneCommander(Node):

    def __init__(self):
        super().__init__('drone_commander')

        self.goto_zero_client = self.create_client(Trigger, 'goto_zero_position')

        self.traj_pub = self.create_publisher(Float32MultiArray, 'traj_cmd', 10)
        self.create_subscription(Int32MultiArray, 'traj_ack', self.on_traj_ack, 10)
        self.last_ack = None    # (command, result) of the most recent /traj_ack

        # Depth 1 so the queue only ever holds the newest mocap sample
        self.create_subscription(PoseStamped, 'crashDrone/pose', self.on_pose, 1)
        self.pose = None        # (n, e, d, yaw [rad]) latest mocap pose
        # The bridge publishes the origin latched, so it arrives even if it
        # was set before this commander started
        self.create_subscription(
            PoseStamped, 'zero_position', self.on_origin,
            QoSProfile(depth=1, durability=DurabilityPolicy.TRANSIENT_LOCAL))
        self.origin = None      # (n, e, d, yaw [rad]) of the origin, mocap frame

        self.get_logger().info('Waiting for position_publisher...')

        deadline = time.time() + 10.0
        while self.traj_pub.get_subscription_count() == 0:
            if time.time() > deadline:
                raise RuntimeError(
                    'nothing is listening on /traj_cmd — is position_publisher running '
                    '(and rebuilt with trajectory command support)?'
                )
            rclpy.spin_once(self, timeout_sec=0.1)

        self.get_logger().info('Connected to position_publisher')

    def on_traj_ack(self, msg):
        if len(msg.data) == 2:
            self.last_ack = (msg.data[0], msg.data[1])

    def on_pose(self, msg):
        p = msg.pose.position
        # mocap frame is already NED
        self.pose = (p.x, p.y, p.z, quaternion_yaw(msg.pose.orientation))

    def on_origin(self, msg):
        p = msg.pose.position
        self.origin = (p.x, p.y, p.z, quaternion_yaw(msg.pose.orientation))

    def current_position(self):
        """
        Fresh mocap pose, or None if none arrives within 1 s. This node
        only processes messages while spinning, so spin here to pick up the
        newest sample.
        """
        self.pose = None
        deadline = time.time() + 1.0
        while self.pose is None and time.time() < deadline:
            rclpy.spin_once(self, timeout_sec=0.05)
        return self.pose

    def save_point(self, path=POINT_FILE, label='save point'):
        pos = self.current_position()
        if pos is None:
            self.get_logger().error(f'[{label}] No mocap data on crashDrone/pose — nothing saved')
            return

        if os.path.exists(path):
            old = read_point_file(path)
            old_text = 'unreadable' if old is None else point_text(old)
            print(f'  {path} already holds a point ({old_text}).')
            if not ask_yes_no('  Overwrite it?'):
                print('  Kept the existing point, nothing saved.')
                return

        n, e, d, yaw = pos
        with open(path, 'w') as f:
            f.write('# Drone saved point: absolute mocap NED position [m] (D positive down), '
                    'yaw [deg] clockwise from North\n')
            f.write(f'{n:.4f} {e:.4f} {d:.4f} {math.degrees(yaw) % 360:.2f}\n')
        self.get_logger().info(f'[{label}] Saved {point_text(pos)} to {path}')

    def load_point(self, path, key, label):
        """(n, e, d, yaw) saved in path, or None (logged) if missing/unreadable."""
        if not os.path.exists(path):
            self.get_logger().error(f'[{label}] No point file at {path} — save one with [{key}]')
            return None
        point = read_point_file(path)
        if point is None:
            self.get_logger().error(f'[{label}] Could not read a point from {path}')
        return point

    def wait_for_origin(self):
        """Spin briefly to pick up the latched origin. True once it is known."""
        deadline = time.time() + 0.3
        while self.origin is None and time.time() < deadline:
            rclpy.spin_once(self, timeout_sec=0.05)
        return self.origin is not None

    def have_origin(self, label):
        if not self.wait_for_origin():
            self.get_logger().error(
                f'[{label}] Origin unknown — set it with [z] first, nothing sent')
            return False
        return True

    def send_saved_point(self, point, label):
        """
        Send an absolute mocap point as a point command: position as an offset
        from the origin, yaw unchanged since it is absolute. True if accepted.
        """
        n, e, d = (p - o for p, o in zip(point[:3], self.origin))
        yaw = point[3]
        print(f'  {label}: {point_text((n, e, d, yaw))} (N/E/D from the origin)')
        return self.send_traj(TRAJ_POINT, [n, e, d, yaw, NAN, NAN, NAN], label)

    def go_to_origin(self):
        """Origin N/E at the current height, facing the origin's yaw if known."""
        yaw = self.origin[3] if self.wait_for_origin() else NAN
        self.send_traj(TRAJ_POINT, [NAN, NAN, NAN, yaw, NAN, NAN, NAN], 'go to origin')

    def goto_saved_point(self):
        point = self.load_point(POINT_FILE, 'w', 'saved point')
        if point is None or not self.have_origin('saved point'):
            return
        self.send_saved_point(point, 'saved point')

    def shuttle(self):
        """
        Fly to A, then back and forth between A and B. Runs until the asked
        number of trips is done, a key is pressed (drone stops and holds),
        or a leg fails or times out.
        """
        a = self.load_point(POINT_A_FILE, '1', 'shuttle')
        b = self.load_point(POINT_B_FILE, '2', 'shuttle')
        if a is None or b is None or not self.have_origin('shuttle'):
            return
        try:
            print('Shuttle A <-> B — Enter alone keeps the default')
            trips = ask('Trips between A and B (A->B = 1, B->A = 2, ...)', 'until stopped')
            pause = ask('Pause at each end [s]', '1')
        except ValueError:
            print('  Not a number — shuttle cancelled, nothing sent.')
            return
        pause = 1.0 if pause != pause else max(pause, 0.0)     # NaN → default

        fd  = sys.stdin.fileno()
        old = termios.tcgetattr(fd)
        tty.setcbreak(fd)       # single keypresses, but log output still formatted
        print('  Shuttling — press any key to stop.')
        try:
            leg = 0             # leg 0 is the flight to A, then one leg per trip
            while trips != trips or leg <= trips:
                name, target = ('A', a) if leg % 2 == 0 else ('B', b)
                if not self.send_saved_point(target, f'shuttle -> {name}'):
                    self.get_logger().warn('[shuttle] Ended — command not accepted')
                    return
                last_leg = trips == trips and leg >= trips      # NaN trips → never
                outcome  = self.wait_for_arrival(target, 0.0 if last_leg else pause)
                if outcome == 'key':
                    os.read(fd, 1024)       # discard the keypress
                    self.send_traj(TRAJ_STOP, [0.0] * 7, 'shuttle stopped')
                    return
                if outcome != 'arrived':
                    self.get_logger().warn(f'[shuttle] Ended — {outcome}')
                    return
                leg += 1
            self.get_logger().info('[shuttle] Done')
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old)

    def wait_for_arrival(self, target, pause):
        """
        Spin until the drone has stayed within ARRIVE_TOLERANCE of target for
        SETTLE_TIME (leaving restarts the timer), then for pause more seconds.
        Returns 'arrived', 'key' (a key was pressed), or
        the reason it gave up.
        """
        start     = time.time()
        in_zone   = None        # time the drone entered the tolerance zone
        arrived   = None        # time it had settled there for SETTLE_TIME
        last_pose = start
        while True:
            if select.select([sys.stdin], [], [], 0)[0]:
                return 'key'
            self.pose = None
            rclpy.spin_once(self, timeout_sec=0.05)
            now = time.time()
            if self.pose is not None:
                last_pose = now
                dist = sum((p - t) ** 2 for p, t in zip(self.pose[:3], target)) ** 0.5
                if dist > ARRIVE_TOLERANCE:
                    in_zone = None
                elif in_zone is None:
                    in_zone = now
                if arrived is None and in_zone is not None and now - in_zone >= SETTLE_TIME:
                    arrived = now
            elif now - last_pose > 1.0:
                return 'no mocap data on crashDrone/pose'
            if arrived is not None and now - arrived >= pause:
                return 'arrived'
            if in_zone is None and arrived is None and now - start > LEG_TIMEOUT:
                return (f'not settled within {ARRIVE_TOLERANCE} m of the point after '
                        f'{LEG_TIMEOUT:.0f} s (stick input cancelled it?)')

    def send_traj(self, command, params, label):
        """
        Publish a trajectory command and report the flight controller's
        answer. The bridge re-sends for up to 2.5 s if the radio link drops
        the command, so wait a little longer than that. True if accepted.
        """
        self.last_ack = None
        msg = Float32MultiArray()
        msg.data = [float(command)] + [float(p) for p in params]
        self.traj_pub.publish(msg)

        deadline = time.time() + 3.5
        while time.time() < deadline:
            rclpy.spin_once(self, timeout_sec=0.05)
            if self.last_ack is not None and self.last_ack[0] == command:
                result = self.last_ack[1]
                text   = ACK_TEXT.get(result, f'result {result}')
                if result == 0:
                    self.get_logger().info(f'[{label}] {text}')
                else:
                    self.get_logger().warn(f'[{label}] {text}')
                return result == 0
        self.get_logger().error(
            f'[{label}] No answer from the flight controller after repeated tries — '
            f'the radio link is not getting through'
        )
        return False

    def call_service(self, client, label):
        """
        Send a Trigger request and log the response.
        Spins internally until the future resolves (3 s timeout).
        """
        if not client.wait_for_service(timeout_sec=1.0):
            self.get_logger().error(f'[{label}] service not available')
            return
        future = client.call_async(Trigger.Request())
        rclpy.spin_until_future_complete(self, future, timeout_sec=3.0)

        if future.result() is not None:
            r = future.result()
            if r.success:
                self.get_logger().info(f'[{label}] {r.message}')
            else:
                self.get_logger().warn(f'[{label}] FAILED: {r.message}')
        else:
            self.get_logger().error(
                f'[{label}] No response (timeout) — is position_publisher running?'
            )


def ask(prompt, default_text):
    """
    Ask for one number. Blank → NaN ("not given"). Raises ValueError on
    anything that is not a number, which cancels the command.
    """
    text = input(f'  {prompt} [{default_text}]: ').strip()
    return NAN if text == '' else float(text)


def quaternion_yaw(q):
    """Yaw [rad] of a quaternion, same convention as the bridge sends the FC."""
    return math.atan2(2.0 * (q.w * q.z + q.x * q.y),
                      q.w * q.w + q.x * q.x - q.y * q.y - q.z * q.z)


def wrap_yaw(yaw):
    """Wrap yaw [rad] to -pi..pi. NaN stays NaN."""
    return math.remainder(yaw, 2.0 * math.pi)


def point_text(point):
    n, e, d, yaw = point
    yaw_text = 'keep heading' if math.isnan(yaw) else f'{math.degrees(yaw) % 360:.1f} deg'
    return f'N={n:.3f}  E={e:.3f}  D={d:.3f}  yaw={yaw_text}'


def ask_yes_no(prompt):
    """Ask until the answer is y or n. Returns True for y."""
    while True:
        text = input(f'{prompt} [y/n]: ').strip().lower()
        if text in ('y', 'n'):
            return text == 'y'
        print('  Please enter y or n.')


def read_point_file(path=POINT_FILE):
    """
    (n, e, d, yaw [rad]) from path, or None if the file does not hold a point.
    Files saved before yaw was added have three numbers: yaw is then NaN.
    """
    try:
        with open(path) as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith('#'):
                    values = [float(v) for v in line.split()]
                    if len(values) == 3:
                        return (*values, NAN)
                    if len(values) == 4:
                        return (*values[:3], wrap_yaw(math.radians(values[3])))
                    return None
    except (OSError, ValueError):
        pass
    return None


def print_menu():
    print('\n' + '=' * 62)
    print('  Drone Commander')
    print('=' * 62)
    print('  BPRL_flight trajectories (fly in POS_HOLD; any roll/pitch/yaw')
    print('  stick input cancels; throttle raises/lowers the trajectory)')
    print('  [z]          Set origin = where the drone is now')
    print('  [g]          Go to the origin  (origin yaw, current height)')
    print('  [p]          Point   — asks for N, E, D, yaw')
    print('  [c]          Circle  — asks for radius, centre, shape, speed')
    print('  [s] / space  STOP    — drone holds position')
    print('  [w]          Save current position + yaw to the point file')
    print('  [t]          Travel to the saved point')
    print('  [1] / [2]    Save current position + yaw as point A / point B')
    print('  [b]          Shuttle back and forth A <-> B  (any key stops)')
    print('  NED offsets from the origin, metres. D is positive DOWN.')
    print('  Yaw in degrees clockwise from North (East = 90).')
    print('-' * 62)
    print('  [a]          ArduPilot: goto zero  (Guided mode + yaw hold)')
    print('  [q]          Quit commander  (bridge keeps running)')
    print('=' * 62 + '\n')


def run_keyboard_loop(node):
    """
    Raw-terminal keyboard loop on the main thread.
    Restores the terminal before each command so prompts and ROS2 logger
    output are not garbled, then returns to raw mode afterwards.
    Does NOT call rclpy.shutdown() on [q] — only this node exits.
    """
    print_menu()

    fd           = sys.stdin.fileno()
    old_settings = termios.tcgetattr(fd)

    def cooked():
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)

    def raw():
        tty.setraw(fd)

    try:
        raw()
        while True:
            ch = sys.stdin.read(1)

            if ch in ('s', ' '):
                cooked()
                node.send_traj(TRAJ_STOP, [0.0] * 7, 'stop')
                raw()

            elif ch == 'z':
                cooked()
                node.send_traj(TRAJ_SET_ORIGIN, [0.0] * 7, 'set origin')
                raw()

            elif ch == 'g':
                cooked()
                node.go_to_origin()
                raw()

            elif ch == 'p':
                cooked()
                try:
                    print('Point — offsets from the origin, Enter alone keeps the default')
                    n = ask('North [m]', '0')
                    e = ask('East [m]', '0')
                    d = ask('Down [m], negative = above the origin', 'current height')
                    yaw = ask('Yaw [deg], clockwise from North', 'current heading')
                    yaw = wrap_yaw(math.radians(yaw))
                    node.send_traj(TRAJ_POINT, [n, e, d, yaw, NAN, NAN, NAN], 'point')
                except ValueError:
                    print('  Not a number — point cancelled, nothing sent.')
                raw()

            elif ch == 'c':
                cooked()
                try:
                    print('Circle — Enter alone keeps the default')
                    radius = ask('Radius [m]', 'required')
                    n      = ask('Centre North [m]', '0')
                    e      = ask('Centre East [m]', '0')
                    d      = ask('Down [m], negative = above the origin', 'current height')
                    focus  = ask('Ellipse focus distance [m]: + long axis North, - East', '0 = circle')
                    direc  = ask('Direction: 1 clockwise from above, -1 counter-clockwise', '1')
                    speed  = ask('Speed [m/s]', 'default')
                    node.send_traj(TRAJ_CIRCLE, [radius, n, e, d, focus, direc, speed], 'circle')
                except ValueError:
                    print('  Not a number — circle cancelled, nothing sent.')
                raw()

            elif ch == 'w':
                cooked()
                node.save_point()
                raw()

            elif ch == 't':
                cooked()
                node.goto_saved_point()
                raw()

            elif ch in ('1', '2'):
                cooked()
                name = 'A' if ch == '1' else 'B'
                node.save_point(POINT_A_FILE if ch == '1' else POINT_B_FILE,
                                f'save point {name}')
                raw()

            elif ch == 'b':
                cooked()
                node.shuttle()
                raw()

            elif ch == 'a':
                cooked()
                node.call_service(node.goto_zero_client, 'goto_zero (ArduPilot)')
                raw()

            elif ch in ('q', '\x03'):   # q or Ctrl+C
                cooked()
                print('\nCommander exiting.  Bridge and drone unaffected.\n')
                break

    except Exception as e:
        cooked()
        print(f'\nKeyboard error: {e}')
    finally:
        # Guarantee terminal is always restored, even on unexpected exit
        try:
            cooked()
        except Exception:
            pass


def main(args=None):
    rclpy.init(args=args)
    node = None
    try:
        node = DroneCommander()
        run_keyboard_loop(node)     # blocks until [q] or error
    except RuntimeError as e:
        print(f'\nCould not start commander: {e}')
    except KeyboardInterrupt:
        print('\nCommander interrupted.  Bridge and drone unaffected.')
    finally:
        if node is not None:
            node.destroy_node()
        try:
            rclpy.shutdown()
        except Exception:
            pass


if __name__ == '__main__':
    main()
