from setuptools import find_packages, setup

package_name = 'position_publisher'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='strain-drone',
    maintainer_email='strain-drone@todo.todo',
    description='TODO: Package description',
    license='TODO: License declaration',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'position_publisher = position_publisher.position_publisher:main',
            'drone_commander = position_publisher.drone_commander:main',
        ],
    },
)
