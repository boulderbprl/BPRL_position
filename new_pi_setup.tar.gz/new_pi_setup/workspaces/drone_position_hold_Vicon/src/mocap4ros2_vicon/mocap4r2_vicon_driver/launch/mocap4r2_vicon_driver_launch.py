# Copyright 2022 Intelligent Robotics Lab
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


import os

from ament_index_python.packages import get_package_share_directory
import launch

from launch import LaunchDescription
from launch.actions import EmitEvent
from launch.actions import SetEnvironmentVariable, DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import LifecycleNode
from launch_ros.events.lifecycle import ChangeState

import lifecycle_msgs.msg

import os
print("LAUNCH ENV LD_LIBRARY_PATH:", os.environ.get("LD_LIBRARY_PATH"))

def generate_launch_description():

    params_file_path = os.path.join(get_package_share_directory(
      'mocap4r2_vicon_driver'), 'config', 'mocap4r2_vicon_driver_params.yaml')

    stdout_linebuf_envvar = SetEnvironmentVariable(
        'RCUTILS_LOGGING_BUFFERED_STREAM', '1')

    # print('')
    # print('params_file_path: ', params_file_path)
    # print('')

    driver_node = LifecycleNode(
        name='mocap4r2_vicon_driver_node',
        namespace=LaunchConfiguration('namespace'),
        package='mocap4r2_vicon_driver',
        executable='mocap4r2_vicon_driver_main',
        output='screen',
        parameters=[LaunchConfiguration('config_file')],
        additional_env={
            'LD_LIBRARY_PATH': (
                '/home/strain-drone/Documents/drone_position_hold_Vicon/ros2_ws/install/mocap4r2_msgs/lib:'
                '/home/strain-drone/Documents/drone_position_hold_Vicon/ros2_ws/install/mocap4r2_vicon_driver/lib:'
                '/home/strain-drone/Documents/drone_position_hold_Vicon/ros2_ws/install/mocap4r2_robot_gt/lib:'
                '/home/strain-drone/Documents/drone_position_hold_Vicon/ros2_ws/install/mocap4r2_robot_gt_msgs/lib:'
                '/home/strain-drone/Documents/drone_position_hold_Vicon/ros2_ws/install/mocap4r2_marker_viz_srvs/lib:'
                '/home/strain-drone/Documents/drone_position_hold_Vicon/ros2_ws/install/mocap4r2_control/lib:'
                '/home/strain-drone/Documents/drone_position_hold_Vicon/ros2_ws/install/mocap4r2_control_msgs/lib:'
                '/opt/ros/jazzy/lib'
            )
        }
    )

    # Make the driver node take the 'configure' transition
    driver_configure_trans_event = EmitEvent(
        event=ChangeState(
            lifecycle_node_matcher=launch.events.matchers.matches_action(driver_node),
            transition_id=lifecycle_msgs.msg.Transition.TRANSITION_CONFIGURE,
        )
    )

    # Make the driver node take the 'activate' transition
    # driver_activate_trans_event = EmitEvent(
    #    event = ChangeState(
    #        lifecycle_node_matcher = launch.events.matchers.matches_action(driver_node),
    #        transition_id = lifecycle_msgs.msg.Transition.TRANSITION_ACTIVATE,
    #     )
    # )

    # Create the launch description and populate
    ld = LaunchDescription()
    ld.add_action(DeclareLaunchArgument('namespace', default_value=''))
    ld.add_action(DeclareLaunchArgument('config_file', default_value=params_file_path))

    ld.add_action(stdout_linebuf_envvar)
    ld.add_action(driver_node)
    ld.add_action(driver_configure_trans_event)
    # ld.add_action(driver_activate_trans_event)

    return ld
