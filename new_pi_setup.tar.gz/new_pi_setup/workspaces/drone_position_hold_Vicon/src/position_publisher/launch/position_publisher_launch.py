import os
from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        Node(
            package='position_publisher',
            executable='position_publisher',
            output='screen',
            additional_env={
                'LD_LIBRARY_PATH': os.environ.get('LD_LIBRARY_PATH', '')
            }
        )
    ])